﻿namespace Extend.Application.Features.Rooms.DTO
{
    public static class RoomDTO
    {
        public class Request
        {
            public string RoomNumber { get; set; }
            public bool IsAvailable { get; set; }
        }

        public class Response
        {
            public Guid Id { get; set; }
            public string RoomNumber { get; set; }
            public bool IsAvailable { get; set; }
        }
    }
}
