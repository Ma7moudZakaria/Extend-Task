﻿using Extend.Application.Features.Users.DTO;
using Extend.Application.Features.Users.Queries;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Extend.Application.Features.Rooms.Queries
{
    internal class GetRoomByIdQuery : IRequest<UserDTO.Response>
    {
        public Guid Id { get; set; }
    }

    public sealed class GetUserByIdQueryHandler : IRequestHandler<GetUserByIdQuery, UserDTO.Response>
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<GetUserByIdQueryHandler> _logger;

        public GetUserByIdQueryHandler(ILogger<GetUserByIdQueryHandler> logger,
                                         IUserRepository userRepo)
        {
            _logger = logger;
            _userRepo = userRepo;
        }

        public async Task<UserDTO.Response> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting user");

            UserModel.Result userResult = await _userRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting user");

            return ItemMapper(userResult);
        }

        private static UserDTO.Response ItemMapper(UserModel.Result item)
        {
            return new UserDTO.Response
            {
                Id = item.Id,
                UserName = item.Username,
                Role = item.Role
            };
        }
    }
}
