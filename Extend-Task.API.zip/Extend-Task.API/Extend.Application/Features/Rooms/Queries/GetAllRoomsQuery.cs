﻿using Extend.Application.Features.Rooms.DTO;
using Extend.Application.Features.Users.DTO;
using Extend.Application.Features.Users.Queries;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend.Application.Features.Rooms.Queries
{
    public class GetAllRoomsQuery : IRequest<IEnumerable<RoomDTO.Response>>
    {
    }

    public sealed class GetAllRoomsQueryHandler : IRequestHandler<GetAllRoomsQuery, IEnumerable<RoomDTO.Response>>
    {
        private readonly IRoomRepository _roomRepo;
        private readonly ILogger<GetAllRoomsQueryHandler> _logger;

        public GetAllRoomsQueryHandler(ILogger<GetAllRoomsQueryHandler> logger,
                                       IRoomRepository roomRepo)
        {
            _logger = logger;
            _roomRepo = roomRepo;
        }

        public async Task<IEnumerable<RoomDTO.Response>> Handle(GetAllRoomsQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting list of rooms");

            List<RoomModel.Result> roomResult = await _roomRepo.GetAllAsync(cancellationToken);

            _logger.LogInformation("Finished getting list of rooms");

            return roomResult.Select(item => ItemMapper(item));
        }

        private static RoomDTO.Response ItemMapper(RoomModel.Result item)
        {
            return new RoomDTO.Response
            {
                Id = item.Id,
                RoomNumber = item.RoomNumber,
                IsAvailable = item.IsAvailable
            };
        }
    }
}
