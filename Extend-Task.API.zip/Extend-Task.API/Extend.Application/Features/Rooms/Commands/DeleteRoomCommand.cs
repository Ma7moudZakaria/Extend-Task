﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Extend.Application.Features.Rooms.Commands
{
    public class DeleteRoomCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
    }

    public sealed class DeleteRoomCommandHandler : IRequestHandler<DeleteRoomCommand, GetExecutionResult>
    {
        private readonly IRoomRepository _roomRepo;
        private readonly ILogger<DeleteRoomCommandHandler> _logger;

        public DeleteRoomCommandHandler(IRoomRepository roomRepo,
                                        ILogger<DeleteRoomCommandHandler> logger)
        {
            _roomRepo = roomRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(DeleteRoomCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting room from database {id}", request.Id);

            RoomModel.Result? room = await _roomRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting room from database {id}", request.Id);

            _logger.LogInformation("Started check if the room exist");

            if (room is null)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "Room is exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the room exist");

            _logger.LogInformation("Started delete room");

            if (await _roomRepo.DeleteAsync(request.Id, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished delete room");

                return new GetExecutionResult
                {
                    Id = Guid.Empty
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }
    }
}
