﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Rooms.DTO.RoomDTO;

namespace Extend.Application.Features.Rooms.Commands
{
    public class UpdateRoomCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
        public Request RoomRequest { get; set; }
    }

    public sealed class UpdateRoomCommandHandler : IRequestHandler<UpdateRoomCommand, GetExecutionResult>
    {
        private readonly IRoomRepository _roomRepo;
        private readonly ILogger<UpdateRoomCommandHandler> _logger;

        public UpdateRoomCommandHandler(IRoomRepository roomRepo,
                                        ILogger<UpdateRoomCommandHandler> logger)
        {
            _roomRepo = roomRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(UpdateRoomCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting room from database {id}", request.Id);

            RoomModel.Result? room = await _roomRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting room from database {id}", request.Id);

            _logger.LogInformation("Started check if the room exist");

            if (room is null)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "Room is exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the room exist");

            _logger.LogInformation("Started mapping room request to room");

            Room roomItem = RoomItemMapperAsync(room.Id, request.RoomRequest);

            _logger.LogInformation("Finished mapping room request to room");

            _logger.LogInformation("Started update room");

            if (await _roomRepo.UpdateAsync(roomItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished update room");

                return new GetExecutionResult
                {
                    Id = roomItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private static Room RoomItemMapperAsync(Guid Id, Request request)
        {
            return new Room
            {
                Id = Id,
                RoomNumber = request.RoomNumber,
                IsAvailable = request.IsAvailable
            };
        }
    }
}
