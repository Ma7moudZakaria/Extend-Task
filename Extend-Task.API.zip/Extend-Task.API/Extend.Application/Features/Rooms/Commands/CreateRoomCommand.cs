﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Rooms.DTO.RoomDTO;

namespace Extend.Application.Features.Rooms.Commands
{
    public class CreateRoomCommand : IRequest<GetExecutionResult>
    {
        public Request RoomRequest { get; set; }
    }

    public sealed class CreateRoomCommandHandler : IRequestHandler<CreateRoomCommand, GetExecutionResult>
    {
        private readonly IRoomRepository _roomRepo;
        private readonly ILogger<CreateRoomCommandHandler> _logger;

        public CreateRoomCommandHandler(IRoomRepository roomRepo,
                                        ILogger<CreateRoomCommandHandler> logger)
        {
            _roomRepo = roomRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(CreateRoomCommand request, CancellationToken cancellationToken)
        {
            // ToDo Add Validation (Fluent Validation)

            _logger.LogInformation("Started mapping room request to room");

            Room roomItem = RoomItemMapper(request.RoomRequest);

            _logger.LogInformation("Finished mapping room request to room");

            _logger.LogInformation("Started create room");

            if (await _roomRepo.CreateAsync(roomItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished create room");

                return new GetExecutionResult
                {
                    Id = roomItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private Room RoomItemMapper(Request item)
        {
            return new Room
            {
                Id = Guid.NewGuid(),
                RoomNumber = item.RoomNumber,
                IsAvailable = item.IsAvailable
            };
        }
    }
}
