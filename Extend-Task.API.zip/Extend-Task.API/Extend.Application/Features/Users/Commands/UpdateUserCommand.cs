﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Users.DTO.UserDTO;

namespace Extend.Application.Features.Users.Commands
{
    public class UpdateUserCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
        public Request UserRequest { get; set; }
    }

    public sealed class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, GetExecutionResult>
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<UpdateUserCommandHandler> _logger;

        public UpdateUserCommandHandler(IUserRepository userRepo,
                                        ILogger<UpdateUserCommandHandler> logger)
        {
            _userRepo = userRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting user from database {id}", request.Id);

            UserModel.Result? user = await _userRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting user from database {id}", request.Id);

            _logger.LogInformation("Started check if the user exist");

            if (user is null) 
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "User is exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the user exist");

            _logger.LogInformation("Started mapping user request to user");

            User userItem = UserItemMapperAsync(user.Id, request.UserRequest);

            _logger.LogInformation("Finished mapping user request to user");

            _logger.LogInformation("Started update user");

            if (await _userRepo.UpdateAsync(userItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished update user");

                return new GetExecutionResult
                {
                    Id = userItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private static User UserItemMapperAsync(Guid Id, Request request)
        {
            return new User
            {
                Id = Id,
                UserName = request.UserName,
                Role = request.Role,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            };
        }
    }
}
