﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Users.DTO.UserDTO;

namespace Extend.Application.Features.Users.Commands
{
    public class CreateUserCommand : IRequest<GetExecutionResult>
    {
        public Request UserRequest { get; set; }
    }

    public sealed class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, GetExecutionResult>
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<CreateUserCommandHandler> _logger;

        public CreateUserCommandHandler(IUserRepository userRepo,
                                          ILogger<CreateUserCommandHandler> logger)
        {
            _userRepo = userRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            // ToDo Add Validation (Fluent Validation)

            _logger.LogInformation("Started mapping user request to user");

            User userItem = UserItemMapper(request.UserRequest);

            _logger.LogInformation("Finished mapping user request to user");

            _logger.LogInformation("Started create user");

            if (await _userRepo.CreateAsync(userItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished create user");

                return new GetExecutionResult
                {
                    Id = userItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private User UserItemMapper(Request item)
        {
            return new User
            {
                Id = Guid.NewGuid(),
                UserName = item.UserName,
                Role = item.Role,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(item.Password),
            };
        }
    }
}
