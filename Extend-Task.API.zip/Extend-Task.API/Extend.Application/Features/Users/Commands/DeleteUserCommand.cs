﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend.Application.Features.Users.Commands
{
    public class DeleteUserCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
    }

    public sealed class DeleteUserCommandHandler : IRequestHandler<DeleteUserCommand, GetExecutionResult>
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<DeleteUserCommandHandler> _logger;

        public DeleteUserCommandHandler(IUserRepository userRepo,
                                        ILogger<DeleteUserCommandHandler> logger)
        {
            _userRepo = userRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting user from database {id}", request.Id);

            UserModel.Result? user = await _userRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting user from database {id}", request.Id);

            _logger.LogInformation("Started check if the user exist");

            if (user is null)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "User is exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the user exist");

            _logger.LogInformation("Started delete user");

            if (await _userRepo.DeleteAsync(request.Id, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished delete user");

                return new GetExecutionResult
                {
                    Id = Guid.Empty
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }
    }
}
