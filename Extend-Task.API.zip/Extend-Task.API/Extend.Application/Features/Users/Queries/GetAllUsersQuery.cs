﻿using Extend.Application.Features.Users.DTO;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Extend.Application.Features.Users.Queries
{
    public class GetAllUsersQuery : IRequest<IEnumerable<UserDTO.Response>>
    {
    }

    public sealed class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, IEnumerable<UserDTO.Response>>
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<GetAllUsersQueryHandler> _logger;

        public GetAllUsersQueryHandler(ILogger<GetAllUsersQueryHandler> logger,
                                         IUserRepository userRepo)
        {
            _logger = logger;
            _userRepo = userRepo;
        }

        public async Task<IEnumerable<UserDTO.Response>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting list of users");

            List<UserModel.Result> userResult = await _userRepo.GetAllAsync(cancellationToken);

            _logger.LogInformation("Finished getting list of users");

            return userResult.Select(item => ItemMapper(item));
        }

        private static UserDTO.Response ItemMapper(UserModel.Result item)
        {
            return new UserDTO.Response
            {
                Id = item.Id,
                UserName = item.Username,
                Role = item.Role
            };
        }
    }
}
