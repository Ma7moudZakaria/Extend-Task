﻿using Extend.Application.Common;
using Extend.Application.Features.Users.DTO;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using static Extend.Application.Features.Users.DTO.UserDTO;

namespace Extend.Application.Features.Users.Queries
{
    public class GetUserByNameQuery : IRequest<string>
    {
        public Request UserRequest { get; set; }
    }

    public sealed class GetUserByNameQueryHandler : IRequestHandler<GetUserByNameQuery, string>
    {
        private readonly IUserRepository _userRepo;
        private readonly IConfiguration _configuration;
        private readonly ILogger<GetUserByNameQueryHandler> _logger;

        public GetUserByNameQueryHandler(ILogger<GetUserByNameQueryHandler> logger,
                                         IUserRepository userRepo,
                                         IConfiguration configuration)
        {
            _logger = logger;
            _userRepo = userRepo;
            _configuration = configuration;
        }

        public async Task<string> Handle(GetUserByNameQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting user");

            UserModel.Result userResult = await _userRepo.GetByUsernameAsync(request.UserRequest.UserName, cancellationToken);

            _logger.LogInformation("Finished getting user");

            _logger.LogInformation("Started check if the user exist");

            bool isUserExist = IsUserExist(userResult, request.UserRequest.Password);

            _logger.LogInformation("Started check if the user exist");

            if (!isUserExist)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "User is not exist", Constants.ErrorCode.NoAuthorized);
            }

            return GenerateJwtToken(userResult);
        }

        private static bool IsUserExist(UserModel.Result userResult, string password)
        {
            if (userResult != null && BCrypt.Net.BCrypt.Verify(password, userResult.PasswordHash))
            {
                return true;
            }

            return false;
        }

        private string GenerateJwtToken(UserModel.Result user)
        {
            // Configure JWT token generation
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            // Define the claims
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                // Add other claims as needed
            };

            // Create the token
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Issuer"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(30), // Token expiration time
                signingCredentials: credentials
            );

            // Return the generated token as a string
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
