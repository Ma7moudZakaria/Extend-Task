﻿namespace Extend.Application.Features.Users.DTO
{
    public static class UserDTO
    {
        public class Request
        {
            public string UserName { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }

        public class Response
        {
            public Guid Id { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }
    }
}
