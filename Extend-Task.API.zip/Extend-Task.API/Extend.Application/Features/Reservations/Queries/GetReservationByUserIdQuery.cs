﻿using Extend.Application.Common;
using Extend.Application.Features.Reservations.DTO;
using Extend.Application.Features.Rooms.DTO;
using Extend.Application.Features.Users.DTO;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Extend.Application.Features.Reservations.Queries
{
    public class GetReservationByUserIdQuery : IRequest<IEnumerable<ReservationDTO.Response>>
    {
        public string UserId { get; set; }
    }

    public sealed class GetReservationByUserIdQueryHandler : IRequestHandler<GetReservationByUserIdQuery, IEnumerable<ReservationDTO.Response>>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly ILogger<GetReservationByUserIdQueryHandler> _logger;

        public GetReservationByUserIdQueryHandler(ILogger<GetReservationByUserIdQueryHandler> logger,
                                                  IReservationRepository reservationRepo)
        {
            _logger = logger;
            _reservationRepo = reservationRepo;
        }

        public async Task<IEnumerable<ReservationDTO.Response>> Handle(GetReservationByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting reservation");

            Guid userId = Guid.Parse(request.UserId);

            List<ReservationModel.Result> userResult = await _reservationRepo.GetByUserIdAsync(userId, cancellationToken);

            _logger.LogInformation("Finished getting reservation");

            return userResult.Select(item => ItemMapper(item));
        }

        private static ReservationDTO.Response ItemMapper(ReservationModel.Result item)
        {
            return new ReservationDTO.Response
            {
                Id = item.Id,
                IsPast = item.IsPast,
                ReservationDate = item.ReservationDate,
                Room = new RoomDTO.Response
                {
                    Id = item.Room.Id,
                    IsAvailable = item.Room.IsAvailable,
                    RoomNumber = item.Room.RoomNumber
                },
                User = new UserDTO.Response
                {
                    Id = item.User.Id,
                    UserName = item.User.Username,
                    Role = item.User.Role
                }
            };
        }
    }
}
