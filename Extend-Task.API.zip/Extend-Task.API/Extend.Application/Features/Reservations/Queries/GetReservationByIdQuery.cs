﻿using Extend.Application.Features.Reservations.DTO;
using Extend.Application.Features.Rooms.DTO;
using Extend.Application.Features.Users.DTO;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Extend.Application.Features.Reservations.Queries
{
    public class GetReservationByIdQuery : IRequest<ReservationDTO.Response>
    {
        public Guid Id { get; set; }
    }

    public sealed class GetReservationByIdQueryHandler : IRequestHandler<GetReservationByIdQuery, ReservationDTO.Response>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly ILogger<GetReservationByIdQueryHandler> _logger;

        public GetReservationByIdQueryHandler(ILogger<GetReservationByIdQueryHandler> logger,
                                              IReservationRepository reservationRepo)
        {
            _logger = logger;
            _reservationRepo = reservationRepo;
        }

        public async Task<ReservationDTO.Response> Handle(GetReservationByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting reservation");

            ReservationModel.Result userResult = await _reservationRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting reservation");

            return ItemMapper(userResult);
        }

        private static ReservationDTO.Response ItemMapper(ReservationModel.Result item)
        {
            return new ReservationDTO.Response
            {
                Id = item.Id,
                IsPast = item.IsPast,
                ReservationDate = item.ReservationDate,
                Room = new RoomDTO.Response
                {
                    Id = item.Room.Id,
                    IsAvailable = item.Room.IsAvailable,
                    RoomNumber = item.Room.RoomNumber
                },
                User = new UserDTO.Response
                {
                    Id = item.User.Id,
                    UserName = item.User.Username,
                    Role = item.User.Role
                }
            };
        }
    }
}
