﻿using Extend.Application.Features.Reservations.DTO;
using Extend.Application.Features.Rooms.DTO;
using Extend.Application.Features.Rooms.Queries;
using Extend.Application.Features.Users.DTO;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend.Application.Features.Reservations.Queries
{
    public class GetAllReservationsQuery : IRequest<IEnumerable<ReservationDTO.Response>>
    {
    }

    public sealed class GetAllReservationsQueryHandler : IRequestHandler<GetAllReservationsQuery, IEnumerable<ReservationDTO.Response>>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly ILogger<GetAllReservationsQueryHandler> _logger;

        public GetAllReservationsQueryHandler(ILogger<GetAllReservationsQueryHandler> logger,
                                              IReservationRepository reservationRepo)
        {
            _logger = logger;
            _reservationRepo = reservationRepo;
        }

        public async Task<IEnumerable<ReservationDTO.Response>> Handle(GetAllReservationsQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting list of reservations");

            List<ReservationModel.Result> roomResult = await _reservationRepo.GetAllAsync(cancellationToken);

            _logger.LogInformation("Finished getting list of reservations");

            return roomResult.Select(item => ItemMapper(item));
        }

        private static ReservationDTO.Response ItemMapper(ReservationModel.Result item)
        {
            return new ReservationDTO.Response
            {
                Id = item.Id,
                IsPast = item.IsPast,   
                ReservationDate = item.ReservationDate,
                Room = new RoomDTO.Response
                {
                    Id = item.Room.Id,
                    IsAvailable = item.Room.IsAvailable,
                    RoomNumber = item.Room.RoomNumber
                },
                User = new UserDTO.Response
                {
                    Id = item.User.Id,
                    UserName = item.User.Username,
                    Role = item.User.Role
                }
            };
        }
    }
}
