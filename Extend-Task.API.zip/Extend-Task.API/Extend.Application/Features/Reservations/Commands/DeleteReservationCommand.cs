﻿using Extend.Application.Common;
using Extend.Application.Features.Rooms.Commands;
using Extend.Application.Repositories;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend.Application.Features.Reservations.Commands
{
    public class DeleteReservationCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
    }

    public sealed class DeleteReservationCommandHandler : IRequestHandler<DeleteReservationCommand, GetExecutionResult>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly ILogger<DeleteReservationCommandHandler> _logger;

        public DeleteReservationCommandHandler(IReservationRepository reservationRepo,
                                               ILogger<DeleteReservationCommandHandler> logger)
        {
            _reservationRepo = reservationRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(DeleteReservationCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting reservation from database {id}", request.Id);

            ReservationModel.Result? reservation = await _reservationRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting reservation from database {id}", request.Id);

            _logger.LogInformation("Started check if the reservation exist");

            if (reservation is null)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "Reservation is exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the reservation exist");

            _logger.LogInformation("Started delete reservation");

            if (await _reservationRepo.DeleteAsync(request.Id, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished delete reservation");

                return new GetExecutionResult
                {
                    Id = Guid.Empty
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }
    }
}
