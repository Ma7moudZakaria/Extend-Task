﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Reservations.DTO.ReservationDTO;

namespace Extend.Application.Features.Reservations.Commands
{
    public class UpdateReservationCommand : IRequest<GetExecutionResult>
    {
        public Guid Id { get; set; }
        public Request ReservationRequest { get; set; }
    }

    public sealed class UpdateReservationCommandHandler : IRequestHandler<UpdateReservationCommand, GetExecutionResult>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly ILogger<UpdateReservationCommandHandler> _logger;

        public UpdateReservationCommandHandler(IReservationRepository reservationRepo,
                                               ILogger<UpdateReservationCommandHandler> logger)
        {
            _reservationRepo = reservationRepo;
            _logger = logger;
        }

        public async Task<GetExecutionResult> Handle(UpdateReservationCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Started getting reservation from database {id}", request.Id);

            ReservationModel.Result? reservation = await _reservationRepo.GetByIdAsync(request.Id, cancellationToken);

            _logger.LogInformation("Finished getting reservation from database {id}", request.Id);

            _logger.LogInformation("Started check if the reservation exist");

            if (reservation is null)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "reservation is not exist", Constants.ErrorCode.NoItemExist);
            }

            _logger.LogInformation("Finished check if the reservation exist");

            _logger.LogInformation("Started mapping reservation request to reservation");

            Reservation reservationItem = ReservationItemMapperAsync(reservation.Id, request.ReservationRequest);

            _logger.LogInformation("Finished mapping reservation request to reservation");

            _logger.LogInformation("Started update reservation");

            if (await _reservationRepo.UpdateAsync(reservationItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished update reservation");

                return new GetExecutionResult
                {
                    Id = reservationItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private static Reservation ReservationItemMapperAsync(Guid Id, Request request)
        {
            return new Reservation
            {
                Id = Id,
                ReservationDate = request.ReservationDate,
                RoomId = request.RoomId,
                UserId = request.UserId
            };
        }
    }
}
