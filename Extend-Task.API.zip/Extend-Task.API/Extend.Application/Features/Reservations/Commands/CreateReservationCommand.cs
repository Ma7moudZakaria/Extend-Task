﻿using Extend.Application.Common;
using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using static Extend.Application.Features.Reservations.DTO.ReservationDTO;

namespace Extend.Application.Features.Reservations.Commands
{
    public class CreateReservationCommand : IRequest<GetExecutionResult>
    {
        public Request ReservationRequest { get; set; }
    }

    public sealed class CreateReservationCommandHandler : IRequestHandler<CreateReservationCommand, GetExecutionResult>
    {
        private readonly IReservationRepository _reservationRepo;
        private readonly IRoomRepository _roomRepo;
        private readonly ILogger<CreateReservationCommandHandler> _logger;

        public CreateReservationCommandHandler(IReservationRepository reservationRepo,
                                        ILogger<CreateReservationCommandHandler> logger,
                                        IRoomRepository roomRepo)
        {
            _reservationRepo = reservationRepo;
            _logger = logger;
            _roomRepo = roomRepo;
        }

        public async Task<GetExecutionResult> Handle(CreateReservationCommand request, CancellationToken cancellationToken)
        {
            // ToDo Add Validation (Fluent Validation)

            _logger.LogInformation("Started check if the reservation exist and available");

            await IsReservationExistAndAvailable(request.ReservationRequest.RoomId, request.ReservationRequest.ReservationDate, cancellationToken);

            _logger.LogInformation("Finished check if the reservation exist and available");

            _logger.LogInformation("Started mapping reservation request to reservation");

            Reservation reservationItem = ReservationItemMapper(request.ReservationRequest);

            _logger.LogInformation("Finished mapping reservation request to reservation");

            _logger.LogInformation("Started create reservation");

            if (await _reservationRepo.CreateAsync(reservationItem, cancellationToken) > 0)
            {
                _logger.LogInformation("Finished create reservation");

                return new GetExecutionResult
                {
                    Id = reservationItem.Id
                };
            }

            throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "No Items have been effected", Constants.ErrorCode.NoItemEffected);
        }

        private async Task IsReservationExistAndAvailable(Guid roomId, DateTime reservationDate, CancellationToken cancellationToken)
        {
            RoomModel.Result room = await _roomRepo.GetByIdAsync(roomId, cancellationToken);

            bool isReservationExist = await _reservationRepo.IsReservationExistAsync(roomId, reservationDate, cancellationToken);

            if (room == null || !room.IsAvailable || isReservationExist)
            {
                throw new CustomException(Constants.HttpCustomErrorCode.CustomError, "Room is not available for the selected date", Constants.ErrorCode.NoItemExist);
            }
        }

        private Reservation ReservationItemMapper(Request item)
        {
            return new Reservation
            {
                Id = Guid.NewGuid(),
                ReservationDate = item.ReservationDate,
                RoomId = item.RoomId,
                UserId = item.UserId
            };
        }
    }
}
