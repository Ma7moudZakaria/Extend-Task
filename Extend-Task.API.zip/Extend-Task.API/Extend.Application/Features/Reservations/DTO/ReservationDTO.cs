﻿using Extend.Application.Features.Rooms.DTO;
using Extend.Application.Features.Users.DTO;

namespace Extend.Application.Features.Reservations.DTO
{
    public static class ReservationDTO
    {
        public class Request
        {
            public DateTime ReservationDate { get; set; }
            public Guid UserId { get; set; }
            public Guid RoomId { get; set; }
        }

        public class Response
        {
            public Guid Id { get; set; }
            public DateTime ReservationDate { get; set; }
            public bool IsPast { get; set; }
            public RoomDTO.Response Room { get; set; }
            public UserDTO.Response User { get; set; }
        }
    }
}
