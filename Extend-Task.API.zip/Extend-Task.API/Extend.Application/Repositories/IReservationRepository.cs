﻿using Extend.Domain.Entities;
using Extend.Domain.Models;
using System.Threading;

namespace Extend.Application.Repositories
{
    public interface IReservationRepository : IRepository<Reservation, ReservationModel.Result>
    {
        Task<bool> IsReservationExistAsync(Guid roomId, DateTime reservationDate, CancellationToken cancellationToken);
        Task<List<ReservationModel.Result>> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken);
    }
}
