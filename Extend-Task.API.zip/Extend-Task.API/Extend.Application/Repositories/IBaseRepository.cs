﻿namespace Extend.Application.Repositories
{
    public interface IRepository<T,TResult> where T : class 
                                            where TResult : class
    {
        Task<TResult> GetByIdAsync(Guid id, CancellationToken cancellationToken);
        Task<List<TResult>> GetAllAsync(CancellationToken cancellationToken);
        Task<int> CreateAsync(T model, CancellationToken cancellationToken);
        Task<int> UpdateAsync(T model, CancellationToken cancellationToken);
        Task<int> DeleteAsync(Guid id, CancellationToken cancellationToken);
    }
}
