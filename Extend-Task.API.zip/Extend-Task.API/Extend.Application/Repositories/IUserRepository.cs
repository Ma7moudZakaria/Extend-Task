﻿using Extend.Domain.Entities;
using Extend.Domain.Models;

namespace Extend.Application.Repositories
{
    public interface IUserRepository : IRepository<User, UserModel.Result>
    {
        Task<UserModel.Result> GetByUsernameAsync(string userName, CancellationToken cancellationToken);
    }
}
