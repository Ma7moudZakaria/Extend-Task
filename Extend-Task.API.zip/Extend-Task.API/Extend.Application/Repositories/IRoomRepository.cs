﻿using Extend.Domain.Entities;
using Extend.Domain.Models;

namespace Extend.Application.Repositories
{
    public interface IRoomRepository : IRepository<Room, RoomModel.Result>
    {
    }
}
