﻿namespace Extend.Application
{
    public interface IMarkupAssemblyScanning
    {
    }
}
