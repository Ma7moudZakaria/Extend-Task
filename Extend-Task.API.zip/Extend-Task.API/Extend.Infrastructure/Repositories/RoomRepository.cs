﻿using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using Extend.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Extend.Infrastructure.Repositories
{
    public class RoomRepository : IRoomRepository
    {
        private readonly ExtendDbContext _dbContext;
        public RoomRepository(ExtendDbContext dbContext) => _dbContext = dbContext;

        public Task<int> CreateAsync(Room model, CancellationToken cancellationToken)
        {
            _dbContext.Set<Room>().Add(model);

            return _dbContext.SaveChangesAsync(cancellationToken);
        }

        public Task<int> DeleteAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Room>()
                             .Where(a => a.Id == id)
                             .ExecuteDeleteAsync(cancellationToken);
        }

        public Task<List<RoomModel.Result>> GetAllAsync(CancellationToken cancellationToken)
        {
            return _dbContext.Set<Room>()
                             .Select(a => new RoomModel.Result
                             {
                                 Id = a.Id,
                                 IsAvailable = a.IsAvailable,
                                 RoomNumber = a.RoomNumber
                             })
                             .ToListAsync(cancellationToken);
        }

        public Task<RoomModel.Result?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Room>()
                             .Where(a => a.Id == id)
                             .Select(a => new RoomModel.Result
                             {
                                 Id = a.Id,
                                 IsAvailable = a.IsAvailable,
                                 RoomNumber = a.RoomNumber
                             })
                             .FirstOrDefaultAsync(cancellationToken);
        }

        public Task<int> UpdateAsync(Room model, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Room>()
                             .Where(a => a.Id == model.Id)
                             .ExecuteUpdateAsync(a => a
                             .SetProperty(a => a.RoomNumber, b => model.RoomNumber)
                             .SetProperty(a => a.IsAvailable, b => model.IsAvailable), cancellationToken);
        }
    }
}
