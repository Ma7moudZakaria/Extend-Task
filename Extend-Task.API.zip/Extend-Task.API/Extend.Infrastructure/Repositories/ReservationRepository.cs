﻿using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using Extend.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Extend.Infrastructure.Repositories
{
    public class ReservationRepository : IReservationRepository
    {
        private readonly ExtendDbContext _dbContext;
        public ReservationRepository(ExtendDbContext dbContext) => _dbContext = dbContext;

        public Task<int> CreateAsync(Reservation model, CancellationToken cancellationToken)
        {
            _dbContext.Set<Reservation>().Add(model);

            return _dbContext.SaveChangesAsync(cancellationToken);
        }

        public Task<int> DeleteAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>()
                             .Where(a => a.Id == id)
                             .ExecuteDeleteAsync(cancellationToken);
        }

        public Task<List<ReservationModel.Result>> GetAllAsync(CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>()
                                   .Include(a => a.User)
                                   .Include(a => a.Room)
                                   .Select(a => new ReservationModel.Result
                                   {
                                       Id = a.Id,
                                       ReservationDate = a.ReservationDate,
                                       IsPast = a.IsPast,
                                       Room = new RoomModel.Result
                                       {
                                           Id = a.Room.Id,
                                           RoomNumber = a.Room.RoomNumber,
                                           IsAvailable = a.Room.IsAvailable
                                       },
                                       User = new UserModel.Result
                                       {
                                           Id = a.User.Id,
                                           PasswordHash = a.User.PasswordHash,
                                           Role = a.User.Role,
                                           Username = a.User.UserName
                                       }
                                   })
                                   .ToListAsync(cancellationToken);
        }

        // We don't expose Domain Entities outsiude the domain.
        public Task<ReservationModel.Result?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>()
                             .Where(a => a.Id == id)
                             .Include(a => a.User)
                             .Include(a => a.Room)
                             .Select(a => new ReservationModel.Result
                             {
                                 Id = a.Id,
                                 ReservationDate = a.ReservationDate,
                                 IsPast = a.IsPast,
                                 Room = new RoomModel.Result
                                 {
                                     Id = a.Room.Id,
                                     RoomNumber = a.Room.RoomNumber,
                                     IsAvailable = a.Room.IsAvailable
                                 },
                                 User = new UserModel.Result
                                 {
                                     Id = a.User.Id,
                                     PasswordHash = a.User.PasswordHash,
                                     Role = a.User.Role,
                                     Username = a.User.UserName
                                 }
                             })
                             .FirstOrDefaultAsync(cancellationToken);
        }

        public Task<List<ReservationModel.Result>> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>()
                             .Where(a => a.UserId == userId)
                             .Include(a => a.User)
                             .Include(a => a.Room)
                             .Select(a => new ReservationModel.Result
                             {
                                 Id = a.Id,
                                 ReservationDate = a.ReservationDate,
                                 IsPast = a.IsPast,
                                 Room = new RoomModel.Result
                                 {
                                     Id = a.Room.Id,
                                     RoomNumber = a.Room.RoomNumber,
                                     IsAvailable = a.Room.IsAvailable
                                 },
                                 User = new UserModel.Result
                                 {
                                     Id = a.User.Id,
                                     PasswordHash = a.User.PasswordHash,
                                     Role = a.User.Role,
                                     Username = a.User.UserName
                                 }
                             })
                             .ToListAsync(cancellationToken);
        }


        public Task<bool> IsReservationExistAsync(Guid roomId, DateTime reservationDate, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>().AnyAsync(a => a.RoomId == roomId &&
                                                               a.ReservationDate == reservationDate, cancellationToken);
        }

        public Task<int> UpdateAsync(Reservation model, CancellationToken cancellationToken)
        {
            return _dbContext.Set<Reservation>()
                             .Where(a => a.Id == model.Id)
                             .ExecuteUpdateAsync(a => a
                             .SetProperty(a => a.ReservationDate, b => model.ReservationDate), cancellationToken);
        }
    }
}
