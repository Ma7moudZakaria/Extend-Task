﻿using Extend.Application.Repositories;
using Extend.Domain.Entities;
using Extend.Domain.Models;
using Extend.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extend.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ExtendDbContext _dbContext;
        public UserRepository(ExtendDbContext dbContext) => _dbContext = dbContext;

        public Task<int> CreateAsync(User model, CancellationToken cancellationToken)
        {
            _dbContext.Set<User>().Add(model);

            return _dbContext.SaveChangesAsync(cancellationToken);
        }

        public Task<int> DeleteAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<User>()
                             .Where(a => a.Id == id)
                             .ExecuteDeleteAsync(cancellationToken);
        }

        public Task<List<UserModel.Result>> GetAllAsync(CancellationToken cancellationToken)
        {
            return _dbContext.Set<User>()
                             .Select(a => new UserModel.Result
                             {
                                 Id = a.Id,
                                 PasswordHash = a.PasswordHash,
                                 Role = a.Role,
                                 Username = a.UserName
                             })
                             .ToListAsync(cancellationToken);
        }

        public Task<UserModel.Result?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
        {
            return _dbContext.Set<User>()
                             .Where(a => a.Id == id)
                             .Select(a => new UserModel.Result
                             {
                                 Id = a.Id,
                                 PasswordHash = a.PasswordHash,
                                 Role = a.Role,
                                 Username = a.UserName
                             })
                             .FirstOrDefaultAsync(cancellationToken);
        }

        public Task<UserModel.Result?> GetByUsernameAsync(string userName, CancellationToken cancellationToken)
        {
            return _dbContext.Set<User>()
                             .Where(a => a.UserName == userName)
                             .Select(a => new UserModel.Result
                             {
                                 Id = a.Id,
                                 PasswordHash = a.PasswordHash,
                                 Role = a.Role,
                                 Username = a.UserName
                             })
                             .FirstOrDefaultAsync(cancellationToken);
        }

        public Task<int> UpdateAsync(User model, CancellationToken cancellationToken)
        {
            return _dbContext.Set<User>()
                             .Where(a => a.Id == model.Id)
                             .ExecuteUpdateAsync(a => a
                             .SetProperty(a => a.UserName, b => model.UserName)
                             .SetProperty(a => a.PasswordHash, b => model.PasswordHash)
                             .SetProperty(a => a.Role, b => model.Role), cancellationToken);
        }
    }
}
