﻿namespace Extend.Infrastructure.Common
{
    public class QueryBase
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; } = 5;
    }
}
