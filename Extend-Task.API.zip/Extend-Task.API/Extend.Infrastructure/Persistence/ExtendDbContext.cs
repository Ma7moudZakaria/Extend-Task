﻿using Extend.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Extend.Infrastructure.Persistence
{
    public class ExtendDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Reservation> Reservations { get; set; }

        public ExtendDbContext(DbContextOptions<ExtendDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            // Configure entity relationships, constraints, etc.
            builder.Entity<Reservation>()
                   .HasOne(r => r.User)
                   .WithMany(u => u.Reservations)
                   .HasForeignKey(r => r.UserId);

            builder.Entity<Reservation>()
                   .HasOne(r => r.Room)
                   .WithMany(rm => rm.Reservations)
                   .HasForeignKey(r => r.RoomId);

            // Seed data for Room
            builder.Entity<Room>().HasData(
                new Room { Id = Guid.Parse("9ddb6f81-a2fc-40f6-86c4-537be3293f11"), RoomNumber = "101", IsAvailable = true },
                new Room { Id = Guid.Parse("4ab7f9e3-152d-4ed0-ac99-aef6f5f08680"), RoomNumber = "102", IsAvailable = true }
            );

            // Seed data for Room
            builder.Entity<User>().HasData(
                new User { Id = Guid.Parse("4ab8f9e3-152d-4ed0-ac99-aef6f5f08680"), UserName = "admin", PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"), Role = "Admin" }
            );

            base.OnModelCreating(builder);
        }
    }
}
