﻿namespace Extend.Infrastructure
{
    public interface IMarkupAssemblyScanning
    {
    }
}
