﻿using Extend.Application.Common;
using Extend.Application.Features.Reservations.Commands;
using Extend.Application.Features.Reservations.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using static Extend.Application.Features.Reservations.DTO.ReservationDTO;

namespace Extend_Task.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly ISender _sender;

        public ReservationController(ISender sender)
        {
            _sender = sender;
        }

        [Authorize]
        [HttpPost]
        public async Task<GetExecutionResult> CreateReservation([FromBody] Request request, CancellationToken cancellationToken)
        {
            return await _sender.Send(new CreateReservationCommand
            {
                ReservationRequest = request
            }, cancellationToken);
        }

        [Authorize]
        [HttpGet("reservations")]
        public async Task<IActionResult> GetUserReservations(CancellationToken cancellationToken)
        {
            string? userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (userId == null)
            {
                return Unauthorized();
            }

            return Ok(await _sender.Send(new GetReservationByUserIdQuery
            {
                UserId = userId
            }, cancellationToken));
        }

        [Authorize]
        [HttpPut("reservations/{id}")]
        public async Task<IActionResult> EditReservation(Guid id, [FromBody] Request request, CancellationToken cancellationToken)
        {
            string? userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            return Ok(await _sender.Send(new UpdateReservationCommand
            {
                Id = id,
                ReservationRequest = new Request
                {
                    ReservationDate = request.ReservationDate,
                    RoomId = request.RoomId,
                    UserId = Guid.Parse(userId)
                }
            }, cancellationToken));
        }

        [Authorize]
        [HttpDelete("reservations/{id}")]
        public async Task<IActionResult> DeleteReservation(Guid id, CancellationToken cancellationToken)
        {
            return Ok(await _sender.Send(new DeleteReservationCommand
            {
                Id = id
            }, cancellationToken));
        }
    }
}
