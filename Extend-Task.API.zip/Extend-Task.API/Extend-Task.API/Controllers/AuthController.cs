﻿using Extend.Application.Common;
using Extend.Application.Features.Users.Commands;
using Extend.Application.Features.Users.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using static Extend.Application.Features.Users.DTO.UserDTO;

namespace Extend_Task.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ISender _sender;

        public AuthController(ISender sender)
        {
            _sender = sender;
        }

        [HttpPost("register")]
        public async Task<GetExecutionResult> Register([FromBody] Request request, CancellationToken cancellationToken)
        {
            return await _sender.Send(new CreateUserCommand
            {
                UserRequest = request
            }, cancellationToken);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Request request, CancellationToken cancellationToken)
        {
            return Ok(await _sender.Send(new GetUserByNameQuery
            {
                UserRequest = request
            }, cancellationToken));
        }
    }
}
