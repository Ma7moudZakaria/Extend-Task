﻿namespace Extend.Domain.Entities
{
    public class Room
    {
        public Guid Id { get; set; }
        public string RoomNumber { get; set; }
        public bool IsAvailable { get; set; }
        public ICollection<Reservation> Reservations { get; set; }
    }
}
