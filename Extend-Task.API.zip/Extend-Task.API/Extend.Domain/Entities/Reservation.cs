﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Extend.Domain.Entities
{
    public class Reservation
    {
        public Guid Id { get; set; }
        public DateTime ReservationDate { get; set; }
        public bool IsPast => ReservationDate < DateTime.Now;
        public Guid UserId { get; set; }
        public Guid RoomId { get; set; }

        [ForeignKey(nameof(UserId))] public User User { get; set; }
        [ForeignKey(nameof(RoomId))] public Room Room { get; set; }
    }
}
