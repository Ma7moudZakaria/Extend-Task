﻿using Extend.Domain.Entities;

namespace Extend.Domain.Models
{
    public class RoomModel
    {
        public class Result
        {
            public Guid Id { get; set; }
            public string RoomNumber { get; set; }
            public bool IsAvailable { get; set; }
            public ICollection<ReservationModel.Result> Reservations { get; set; }
        }
    }
}
