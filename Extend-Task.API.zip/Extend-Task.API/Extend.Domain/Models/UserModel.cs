﻿namespace Extend.Domain.Models
{
    public class UserModel
    {
        public class Result
        {
            public Guid Id { get; set; }
            public string Username { get; set; }
            public string PasswordHash { get; set; }
            public string Role { get; set; }
            public ICollection<ReservationModel.Result> Reservations { get; set; }
        }
    }
}
