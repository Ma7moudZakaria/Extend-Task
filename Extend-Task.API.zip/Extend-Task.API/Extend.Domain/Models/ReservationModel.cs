﻿namespace Extend.Domain.Models
{
    public class ReservationModel
    {
        public class Result
        {
            public Guid Id { get; set; }
            public DateTime ReservationDate { get; set; }
            public bool IsPast { get; set; }
            public UserModel.Result User { get; set; }
            public RoomModel.Result Room { get; set; }
        }
    }
}
